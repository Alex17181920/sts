package com.example.library.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.library.model.Author;
import com.example.library.model.Book;
import com.example.library.repository.AuthorRepository;
import com.example.library.repository.BookRepository;

@Service
public class LibraryService {

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private AuthorRepository authorRepository;

    // Add new book and author
    public void addBookAndAuthor(Book book, Author author) {
        // Set the author for the book
        book.setAuthor(author);
        
        // Save the author and book to the repository
        authorRepository.save(author);
        bookRepository.save(book);
    }
    

    // Update book details
    @Transactional
    public void updateBook(Long bookId, Book updatedBook) {
        Optional<Book> bookOptional = bookRepository.findById(bookId);
        if (bookOptional.isPresent()) {
            Book book = bookOptional.get();
            book.setTitle(updatedBook.getTitle());
            book.setIsbn(updatedBook.getIsbn());
            book.setPublishedDate(updatedBook.getPublishedDate());
            book.setNumberOfCopies(updatedBook.getNumberOfCopies());
            bookRepository.save(book);
        }
    }

    // Get all books and their authors
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    // Search books by title or author name
    public List<Book> searchBooks(String searchTerm) {
        List<Book> booksByTitle = bookRepository.findByTitleContaining(searchTerm);
        List<Book> booksByAuthor = bookRepository.findByAuthorNameContaining(searchTerm);
        booksByTitle.addAll(booksByAuthor);
        return booksByTitle;
    }
}
