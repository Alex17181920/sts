package com.example.taskmanagement.model;

public enum Status {

	PENDING,
	IN_PROGRESS,
	COMPLETED
}
