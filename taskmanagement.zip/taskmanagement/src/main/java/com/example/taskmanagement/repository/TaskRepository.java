package com.example.taskmanagement.repository;

import com.example.taskmanagement.model.*;
import org.springframework.data.jpa.repository.*;
import java.util.*;

public interface TaskRepository extends JpaRepository<Task, Long> {

	List<Task> findByStatus(Status status);
}
