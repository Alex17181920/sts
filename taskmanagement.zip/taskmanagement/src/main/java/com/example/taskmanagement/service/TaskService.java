package com.example.taskmanagement.service;

import com.example.taskmanagement.model.*;
import java.util.*;

public interface TaskService {

	Task createTask(Task task);
    Task updateTask(Long id, Task taskDetails);
    void deleteTask(Long id);
    List<Task> getAllTasks();
    List<Task> getTasksByStatus(Status status);
    Optional<Task> getTaskById(Long id);
}
