package com.example.taskmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
